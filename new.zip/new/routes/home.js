var express=require('express');
const Companies = require('../models/Companies');
var router=express.Router();
var auth=require('../middleware/auth.js');
const Users = require('../models/Users');

router.get('/',auth,(req,res,next)=>{
    Companies.find({})
    .then((companies)=>{
     // extract payload(_id) from jwt token stored in cookies.
    const base64url = req.cookies.jwt.split(".")[1]; // the jwt token consists of 1)header 2) payload 3)signature seprated by dots 
    
    // now convert the base64 encoded payload to json object 
    const decodedValue= JSON.parse( Buffer.from(base64url, 'base64'));
     
    // extract _id from payload object.
    console.log(decodedValue._id);
     
    Users.findById(decodedValue._id)
    .then((user)=>{
        res.render('home',{companies: companies,user:user});
    })
    .catch((err)=>{

    })
   
    })
    .catch((err)=>{
        console.log(err);
    })
});

router.get('/:id',(req,res,next)=>{
   
    Companies.findById(req.params.id)
    .then((company)=>{
        console.log(company.name);    
        res.render('company',{company: company});
        })
    .catch((err)=>{
        console.log(err);
    })
})


router.get('/delete/:id',(req,res,next)=>{
    Companies.findByIdAndRemove(req.params.id)
    .then((company)=>{
        res.redirect('/home'); 
    })
    .catch((err)=>{
        console.log(err);
    })
})
module.exports=router;